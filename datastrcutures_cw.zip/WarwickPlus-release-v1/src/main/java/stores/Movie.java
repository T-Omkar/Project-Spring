package stores;

import java.util.Calendar;

import structures.DynamicArray;

public class Movie {
    private String title;
    private String originalTitle;
    private String overview;
    private String tagline;
    private String status;
    private Genre[] genres;
    private Calendar release;
    private long budget;
    private long revenue;
    private String[] languages;
    private String originalLanguage;
    private double runtime;
    private String homepage;
    private boolean adult;
    private boolean video;
    private String poster;
    private double voteAverage;
    private int voteCount;
    private Collection belongs_to_collection;
    private String imdb_id;
    private double popularity;
    private DynamicArray<Company> productionCompanies;
    private DynamicArray<String> productionCountries;

    public Movie(String title, String originalTitle, String overview, String tagline, String status,
            Genre[] genres, Calendar release, long budget, long revenue, String[] languages,
            String originalLanguage, double runtime, String homepage, boolean adult, boolean video, String poster) {

        this.title = title;
        this.originalTitle = originalTitle;
        this.overview = overview;
        this.tagline = tagline;
        this.status = status;
        this.genres = genres;
        this.release = release;
        this.budget = budget;
        this.revenue = revenue;
        this.languages = languages;
        this.originalLanguage = originalLanguage;
        this.runtime = runtime;
        this.homepage = homepage;
        this.adult = adult;
        this.video = video;
        this.poster = poster;
        this.belongs_to_collection = null;
        this.productionCompanies = new DynamicArray<Company>(); // initialize variable
        this.productionCountries = new DynamicArray<String>();
    }

    public String getTitle() {
        return this.title;
    }

    public String getOriginalTitle() {
        return this.originalTitle;
    }

    public String getOverview() {
        return this.overview;
    }

    public String getTagline() {
        return this.tagline;
    }

    public String getStatus() {
        return this.status;
    }

    public Genre[] getGenres() {
        return this.genres;
    }

    public Calendar getRelease() {
        return this.release;
    }

    public long getBudget() {
        return this.budget;
    }

    public long getRevenue() {
        return this.revenue;
    }

    public String[] getLanguages() {
        return this.languages;
    }

    public String getOriginalLanguage() {
        return this.originalLanguage;
    }

    public double getRuntime() {
        return this.runtime;
    }

    public String getHomepage() {
        return this.homepage;
    }

    public boolean getAdult() {
        return this.adult;
    }

    public boolean getVideo() {
        return this.video;
    }

    public String getPoster() {
        return this.poster;
    }

    public void setVoteAverage(double voteAverage) {
        this.voteAverage = voteAverage;
    }

    public void setVoteCount(int voteCount) {
        this.voteCount = voteCount;
    }

    public double getVoteAverage() {
        return this.voteAverage;
    }

    public int getVoteCount() {
        return this.voteCount;
    }

    public void setCollection(Collection collection) {
        this.belongs_to_collection = collection;
    }

    public Collection getCollection() {
        return this.belongs_to_collection;
    }

    public void setImdb_Id(String imdb_id) {
        this.imdb_id = imdb_id;
    }

    public void setIMDB_id(String imdb_id) {
        this.imdb_id = imdb_id;
    }

    public String getIMDB_id() {
        return this.imdb_id;
    }

    public void setPopularity(double popularity) {
        this.popularity = popularity;
    }

    public double getPopularity() {
        return this.popularity;
    }

    public DynamicArray<Company> getProductionCompanies() {
        return this.productionCompanies;
    }

    public void addProductionCompany(Company company) {
        productionCompanies.add(company);
    }

    public DynamicArray<String> getProductionCountries() {
        return productionCountries;
    }

    public void addProductionCountry(String country) {
        productionCountries.add(country);
    }

}