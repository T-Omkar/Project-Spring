package stores;

import java.util.Calendar;

public class Rating implements Comparable<Rating> {
    private int userId;
    private int movieId;
    private float rating;
    private Calendar timestamp;

    public Rating(int userId, int movieId, float rating, Calendar timestamp) {
        this.userId = userId;
        this.movieId = movieId;
        this.rating = rating;
        this.timestamp = timestamp;
    }

    public float getRating() {
        return this.rating;
    }

    public Calendar getTimestamp() {
        return this.timestamp;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public void setTimestamp(Calendar timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public int compareTo(Rating rating) {
        if (this.rating < rating.rating) {
            return -1;
        } else if (this.rating > rating.rating) {
            return 1;
        } else {
            return 0;
        }
    }
}
