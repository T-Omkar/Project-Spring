package stores;

import java.util.Calendar;

import interfaces.IRatings;
import structures.*;

import java.util.Arrays;

public class Ratings implements IRatings {

    // This first hashmap acts as a lookup table containing all the necessary values
    private KVHashMap<String, Rating> ratingsTable;
    // the next 3 hashmaps are sorted by key and are used as indexed tables for
    // quick access
    private KVHashMap<Integer, Set<String>> userIndex; // TODO: change this from set to array bc set doesnt provide any
                                                       // advantage just makes it slower
    private KVHashMap<Integer, Set<String>> movieIndex;

    // instead of indexing the dates via a hashmap I index them by date so that the
    // order is retained.
    MyBinaryTree<Long, String> dateIndexTree;

    public Ratings() {
        ratingsTable = new KVHashMap<>();

        userIndex = new KVHashMap<>();
        movieIndex = new KVHashMap<>();
        dateIndexTree = new MyBinaryTree<>();
    }

    /**
     * Adds a rating to the data structure. The rating is made unique by its user ID
     * and its movie ID
     * 
     * @param userID    The user ID
     * @param movieID   The movie ID
     * @param rating    The rating gave to the film by this user (between 0 and 5
     *                  inclusive)
     * @param timestamp The time at which the rating was made
     * @return TRUE if the data able to be added, FALSE otherwise
     */
    @Override
    public boolean add(int userID, int movieID, float rating, Calendar timestamp) {
        // create unique key
        String key = userID + ":" + movieID;

        if (ratingsTable.containsKey(key)) {
            return false;
        }

        // add to lookup table
        Rating newRating = new Rating(userID, movieID, rating, timestamp);
        ratingsTable.add(key, newRating);

        // add to indexing tables
        Set<String> keySet = userIndex.get(userID);
        if (keySet == null) {
            keySet = new Set<>();
        }
        keySet.add(key);
        userIndex.add(userID, keySet);

        keySet = movieIndex.get(movieID);
        if (keySet == null) {
            keySet = new Set<>();
        }
        keySet.add(key);
        movieIndex.add(movieID, keySet);

        // add to date index tree
        dateIndexTree.add(timestamp.getTimeInMillis() / 1000, key);

        return true;

    }

    /**
     * Removes a given rating, using the user ID and the movie ID as the unique
     * identifier
     * 
     * @param userID  The user ID
     * @param movieID The movie ID
     * @return TRUE if the data was removed successfully, FALSE otherwise
     */
    @Override
    public boolean remove(int userID, int movieID) {
        // Create unique key
        String key = userID + ":" + movieID;

        // Check if rating exists in the ratingsTable
        if (!ratingsTable.containsKey(key)) {
            return false;
        }

        // Remove rating from the ratingsTable
        Rating removedRating = ratingsTable.remove(key);

        // Remove key from the index tables
        Set<String> userSet = userIndex.get(userID);
        userSet.remove(key);
        if (userSet.isEmpty()) { // remove the rating from the set, if there are no more ratings, then remove the
                                 // userID from the hashmap as well
            userIndex.remove(userID);
        }

        Set<String> movieSet = movieIndex.get(movieID);
        movieSet.remove(key);
        if (movieSet.isEmpty()) {
            movieIndex.remove(movieID);
        }

        dateIndexTree.remove(removedRating.getTimestamp().getTimeInMillis() / 1000, key);

        return true;
    }

    /**
     * Sets a rating for a given user ID and movie ID. Therefore, should the given
     * user have already rated the given movie, the new data should overwrite the
     * existing rating. However, if the given user has not already rated the given
     * movie, then this rating should be added to the data structure
     * 
     * @param userID    The user ID
     * @param movieID   The movie ID
     * @param rating    The new rating to be given to the film by this user (between
     *                  0 and 5 inclusive)
     * @param timestamp The time at which the rating was made
     * @return TRUE if the data able to be added/updated, FALSE otherwise
     */
    @Override
    public boolean set(int userID, int movieID, float rating, Calendar timestamp) {
        String key = userID + ":" + movieID;

        if (!ratingsTable.containsKey(key)) {
            // If rating does not exist, call add method to add new rating
            return add(userID, movieID, rating, timestamp);
        }

        // Retrieve the existing rating object from ratingsTable and update its values
        Rating existingRating = ratingsTable.get(key);
        existingRating.setRating(rating);
        existingRating.setTimestamp(timestamp);

        // update the date index tree - since movieindex and userindex will not change
        dateIndexTree.remove(timestamp.getTimeInMillis() / 1000, key);
        dateIndexTree.add(timestamp.getTimeInMillis() / 1000, key);

        return true;
    }

    /**
     * Find all ratings between a given start date and end date. If a rating falls
     * exactly on a given start date or a given end date, then this should not be
     * included
     * 
     * @param start The start time for the range
     * @param end   The end time for the range
     * @return An array of ratings between start and end. If there are no ratings,
     *         then return an empty array
     */
    @Override
    public float[] getRatingsBetween(Calendar start, Calendar end) {
        long startTime = start.getTimeInMillis() / 1000;
        long endTime = end.getTimeInMillis() / 1000;
        Set<String> ratingKeys = dateIndexTree.getValuesBetween(startTime, endTime);

        float[] ratings = new float[ratingKeys.size()];
        SetIterator<String> keyIterator = ratingKeys.iterator();
        for (int i = 0; i < ratings.length && keyIterator.hasNext(); i++) {
            Rating rating = ratingsTable.get(keyIterator.next());
            ratings[i] = rating.getRating();
        }

        return ratings;
    }

    /**
     * Find all ratings for a given film, between a given start date and end date.
     * If a rating falls exactly on a given start date or a given end date, then
     * this should not be included
     * 
     * @param movieID The movie ID
     * @param start   The start time for the range
     * @param end     The end time for the range
     * @return An array of ratings between start and end for a given film. If there
     *         are no ratings, then return an empty array
     */
    @Override
    public float[] getMovieRatingsBetween(int movieId, Calendar start, Calendar end) {
        long startTime = start.getTimeInMillis() / 1000;
        long endTime = end.getTimeInMillis() / 1000;

        // Get all rating IDs that fall within the given date range
        Set<String> ratingIdsInRange = dateIndexTree.getValuesBetween(startTime, endTime);

        // Get all rating IDs for the given movie
        Set<String> ratingIdsForMovie = movieIndex.get(movieId);

        if (ratingIdsForMovie == null) {
            // No ratings found for this movie
            return new float[0];
        }

        // Get the set of rating IDs that belong to both sets
        Set<String> commonRatingIds = ratingIdsInRange.intersection(ratingIdsForMovie);

        // Retrieve the rating objects for the common rating IDs
        DynamicArray<Float> ratingsList = new DynamicArray<>();
        SetIterator<String> iterator = new SetIterator<>(commonRatingIds);
        while (iterator.hasNext()) {
            String ratingId = iterator.next();
            Rating rating = ratingsTable.get(ratingId);
            if (rating != null) {
                ratingsList.add(rating.getRating());
            }
        }

        // Convert the list of ratings to an array
        float[] ratingsArray = new float[ratingsList.size()];
        for (int i = 0; i < ratingsList.size(); i++) {
            ratingsArray[i] = ratingsList.get(i);
        }
        return ratingsArray;
    }

    /**
     * Find all ratings for a given user, between a given start date and end date.
     * If a rating falls exactly on a given start date or a given end date, then
     * this should not be included
     * 
     * @param userID The user ID
     * @param start  The start time for the range
     * @param end    The end time for the range
     * @return An array of ratings between start and end for a given user. If there
     *         are no ratings, then return an empty array
     */
    @Override
    public float[] getUserRatingsBetween(int userID, Calendar start, Calendar end) {
        long startTime = start.getTimeInMillis() / 1000;
        long endTime = end.getTimeInMillis() / 1000;

        // Get all rating IDs that fall within the given date range
        Set<String> ratingIdsInRange = dateIndexTree.getValuesBetween(startTime, endTime);

        // Get all rating IDs for the given user
        Set<String> ratingIdsForUser = userIndex.get(userID);

        if (ratingIdsForUser == null) {
            // No ratings found for this user
            return new float[0];
        }

        // Get the set of rating IDs that belong to both sets
        Set<String> commonRatingIds = ratingIdsInRange.intersection(ratingIdsForUser);

        // Retrieve the rating objects for the common rating IDs
        DynamicArray<Float> ratingsList = new DynamicArray<>();
        SetIterator<String> iterator = new SetIterator<>(commonRatingIds);
        while (iterator.hasNext()) {
            String ratingId = iterator.next();
            Rating rating = ratingsTable.get(ratingId);
            if (rating != null) {
                ratingsList.add(rating.getRating());
            }
        }

        // Convert the list of ratings to an array
        float[] ratingsArray = new float[ratingsList.size()];
        for (int i = 0; i < ratingsList.size(); i++) {
            ratingsArray[i] = ratingsList.get(i);
        }
        return ratingsArray;
    }

    /**
     * Get all the ratings for a given film
     * 
     * @param movieID The movie ID
     * @return An array of ratings. If there are no ratings or the film cannot be
     *         found, then return an empty array
     */
    @Override
    public float[] getMovieRatings(int movieID) {
        // get the set of rating IDs for the given movieID
        Set<String> ratingIds = movieIndex.get(movieID);
        if (ratingIds == null) {
            // if no ratings found
            return new float[0];
        }

        // Create an array to store the ratings
        float[] ratingsArray = new float[ratingIds.size()];

        // Loop through all the rating IDs for this movie
        for (int i = 0; i < ratingsArray.length; i++) {
            String ratingId = (String) ratingIds.toArray()[i];
            Rating rating = ratingsTable.get(ratingId);
            if (rating != null) {
                // Add the rating to the array of ratings
                ratingsArray[i] = rating.getRating();
            }
        }

        return ratingsArray;
    }

    /**
     * Get all the ratings for a given user
     * 
     * @param userID The user ID
     * @return An array of ratings. If there are no ratings or the user cannot be
     *         found, then return an empty array
     */
    @Override
    public float[] getUserRatings(int userID) {
        Set<String> ratingIds = userIndex.get(userID); // similar to prev function
        if (ratingIds == null) {
            return new float[0];
        }

        // array to store the ratings
        float[] ratingsArray = new float[ratingIds.size()];

        for (int i = 0; i < ratingsArray.length; i++) {
            String ratingId = (String) ratingIds.toArray()[i];
            Rating rating = ratingsTable.get(ratingId);
            if (rating != null) {
                ratingsArray[i] = rating.getRating();
            }
        }

        return ratingsArray;
    }

    /**
     * Get the average rating for a given film
     * 
     * @param movieID The movie ID
     * @return Produces the average rating for a given film. If the film cannot be
     *         found, or there are no rating, return 0
     */
    @Override
    public float getMovieAverageRatings(int movieID) {
        float[] ratings = getMovieRatings(movieID);

        if (ratings.length == 0) {
            return 0;
        }

        float sum = 0;
        for (int i = 0; i < ratings.length; i++) {
            sum += ratings[i];
        }

        return sum / ratings.length;
    }

    /**
     * Get the average rating for a given user
     * 
     * @param userID The user ID
     * @return Produces the average rating for a given user. If the user cannot be
     *         found, or there are no rating, return 0
     */
    @Override
    public float getUserAverageRatings(int userID) {
        float[] ratings = getUserRatings(userID);
        if (ratings.length == 0) {
            return 0;
        }
        float sum = 0;
        for (int i = 0; i < ratings.length; i++) {
            sum += ratings[i];
        }
        return sum / ratings.length;
    }

    /**
     * Gets the top N films with the most ratings, in order from most to least
     *
     * @param num The number of films that should be returned
     * @return A sorted array of film IDs with the most ratings. The array should be
     *         no larger than num. If there are less than num films in the store,
     *         then the array should be the same length as the number of films
     */
    @Override
    public int[] getTopMovies(int num) {
        // Create a max heap to store the top N films with the most ratings
        MaxHeap<Integer> maxHeap = new MaxHeap<>();
        DynamicArray<Integer> movieIndexEntries = movieIndex.getKeys();
        for (int i = 0; i < movieIndexEntries.size(); i++) {
            int movieId = movieIndexEntries.get(i);
            int numRatings = movieIndex.get(movieId).size();
            maxHeap.insert(movieId, numRatings);
        }

        // Extract the top N films from the heap
        int[] topMovies = new int[Math.min(num, maxHeap.size())];
        for (int i = 0; i < topMovies.length; i++) {
            topMovies[i] = maxHeap.extractMax().getData();
        }

        System.out.println(Arrays.toString(topMovies));
        return topMovies;
    }

    /**
     * Gets the top N users with the most ratings, in order from most to least
     * 
     * @param num The number of users that should be returned
     * @return A sorted array of user IDs with the most ratings. The array should be
     *         no larger than num. If there are less than num users in the store,
     *         then the array should be the same length as the number of users
     */
    @Override
    public int[] getMostRatedUsers(int num) {
        MaxHeap<Integer> heap = new MaxHeap<>();
        DynamicArray<Integer> userIds = userIndex.getKeys();
        for (int i = 0; i < userIds.size(); i++) {
            int userId = userIds.get(i);
            int numRatings = userIndex.get(userId).size();
            heap.insert(userId, numRatings);
        }

        // Extract the top N users from the heap by calling extract max n times
        int[] topUsers = new int[Math.min(num, heap.size())];
        for (int i = 0; i < topUsers.length; i++) {
            topUsers[i] = heap.extractMax().getData();
        }

        System.out.println(Arrays.toString(topUsers));
        return topUsers;
    }

    /**
     * Gets the number of ratings in the data structure
     * 
     * @return The number of ratings in the data structure
     */
    @Override
    public int size() {
        return ratingsTable.size();
    }

}
