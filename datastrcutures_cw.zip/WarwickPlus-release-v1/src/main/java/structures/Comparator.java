package structures;

public interface Comparator<T> {

}
