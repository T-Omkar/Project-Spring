package structures;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class KVHashMapIterator<K extends Comparable<K>, V> implements Iterator<K> {
    private KVHashMap<K, V> map;
    private int currentIndex;

    public KVHashMapIterator(KVHashMap<K, V> map) {
        this.map = map;
        this.currentIndex = 0;
    }

    @Override
    public boolean hasNext() {
        return currentIndex < map.size();
    }

    @Override
    public K next() {
        if (!hasNext()) {
            throw new NoSuchElementException("ran out of keys to iterate good luck");
        }

        K key = map.getKeys().get(currentIndex);
        currentIndex++;
        return key;
    }

}
