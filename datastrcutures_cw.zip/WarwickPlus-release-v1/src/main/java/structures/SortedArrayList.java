package structures;

public class SortedArrayList<T extends Comparable<T>> {
    private T[] array;
    private int size;

    public SortedArrayList() {
        this.array = (T[]) new Comparable[10];
        this.size = 0;
    }

    public void add(T element) {
        if (this.size == this.array.length) {
            resize();
        }

        int index = this.binarySearch(element);
        if (index < 0) {
            index = -(index + 1);
        }
        for (int i = this.size; i > index; i--) {
            this.array[i] = this.array[i - 1];
        }
        this.array[index] = element;
        this.size++;
    }

    public T get(int index) {
        if (index < 0 || index >= this.size) {
            throw new IndexOutOfBoundsException();
        }
        return this.array[index];
    }

    public int size() {
        return this.size;
    }

    private int binarySearch(T element) {
        int left = 0;
        int right = this.size - 1;
        while (left <= right) {
            int mid = (left + right) / 2;
            int cmp = this.array[mid].compareTo(element);
            if (cmp == 0) {
                return mid;
            } else if (cmp < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return -(left + 1);
    }

    private void resize() {
        T[] newArray = (T[]) new Comparable[2 * this.array.length];
        for (int i = 0; i < this.size; i++) {
            newArray[i] = this.array[i];
        }
        this.array = newArray;
    }
}
