package structures;

class BTNode<K, V extends Comparable<V>> {
    K key;
    Set<V> values;
    BTNode<K, V> left, right;

    public BTNode(K key, V value) {
        this.key = key;
        this.values = new Set();
        this.values.add(value);
        this.left = this.right = null;
    }

    public K getKey() {
        return key;
    }

    public Set<V> getValues() {
        return values;
    }

    public BTNode<K, V> getLeft() {
        return left;
    }

    public BTNode<K, V> getRight() {
        return right;
    }

    public void setKey(K key) {
        this.key = key;
    }

    public void setValues(Set<V> values) {
        this.values = values;
    }

    public void setLeft(BTNode<K, V> left) {
        this.left = left;
    }

    public void setRight(BTNode<K, V> right) {
        this.right = right;
    }

    public void addValue(V value) {
        this.values.add(value);
    }

}
