package structures;

public class DynamicArray<E> implements IList<E> {

    private Object[] array;
    private int size;
    private int capacity;

    public DynamicArray() {
        this.capacity = 100;
        this.array = new Object[capacity];
        this.size = 0;
    }

    public boolean add(E element) {
        boolean flag = false;
        // Adds element to the list, returns true on success and false otherwise.
        if (size < capacity) {
            array[size] = element; // size bc its zero indexed
            size++;
            flag = true;
        } else {
            // create a new array of double the size and copy everything from the previous
            // array over
            Object[] newArray = new Object[capacity + 10]; // adds 10 new spaces if array is full
            capacity = capacity + 10;
            for (int index = 0; index < array.length; index++) { // copy previous array
                newArray[index] = array[index];
            }
            newArray[size] = element;
            array = newArray;
            size++;
            flag = true;

        }
        return flag;
    }

    public boolean contains(E element) {
        for (int i = 0; i < size; i++) {
            if (array[i].equals(element)) {
                return true;
            }
        }
        return false;
    }

    public void clear() {
        this.capacity = 100;
        this.array = new Object[capacity];
        this.size = 0;
    }

    public boolean isEmpty() {
        return this.size() == 0;
    }

    public int size() {
        return size;
    }

    public E get(int index) {
        return (E) this.array[index];
    }

    public int indexOf(E element) {
        for (int i = 0; i < this.size(); i++) {
            if (element.equals(this.get(i))) {
                return i;
            }
        }
        return -1;
    }

    public boolean remove(E element) {
        int index = indexOf(element);
        if (index == -1) {
            return false;
        } else {
            remove(index);
            return true;
        }
    }

    public E remove(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Invalid index: " + index);
        }
        E removed = get(index);
        for (int i = index; i < size - 1; i++) {
            array[i] = array[i + 1];
        }
        array[size - 1] = null;
        size--;
        return removed;
    }

    public E set(int index, E element) {
        if (index >= this.size()) {
            throw new ArrayIndexOutOfBoundsException("index > size: " + index + " >= " + size);
        }
        E replaced = this.get(index);
        this.array[index] = element;
        return replaced;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for (int i = 0; i < size; i++) {
            sb.append(array[i]);
            if (i != size - 1) {
                sb.append(", ");
            }
        }
        sb.append("]");
        return sb.toString();
    }

    public DynamicArrayIterator<E> iterator() {
        return new DynamicArrayIterator<E>(this);
    }

}
