package structures;

public class SetIterator<E extends Comparable<E>> {

    private DynamicArray<E> array;
    private int currentIndex;

    public SetIterator(Set<E> set) {
        this.array = set.getArray();
        this.currentIndex = 0;
    }

    public boolean hasNext() {
        return currentIndex < array.size();
    }

    public E next() {
        if (hasNext()) {
            E nextElement = array.get(currentIndex);
            currentIndex++;
            return nextElement;
        } else {
            return null;
        }
    }
}
