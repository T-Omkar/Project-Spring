package structures;

public class KVHashMap<K extends Comparable<K>, V> {

    private static final int INITIAL_CAPACITY = 97;
    private static final int[] PRIMES = { 101, 211, 431, 877, 1753, 3527, 7057, 14207 };

    protected KVLinkedList<K, V>[] table;
    protected int size;
    protected int threshold;

    public KVHashMap() {
        this(INITIAL_CAPACITY);
    }

    public KVHashMap(int initialCapacity) {
        int index = 0;
        while (index < PRIMES.length && PRIMES[index] < initialCapacity) {
            index++;
        }
        table = new KVLinkedList[PRIMES[index]];
        initTable();
        threshold = (int) (table.length * 0.75);
    }

    protected void initTable() {
        for (int i = 0; i < table.length; i++) {
            table[i] = new KVLinkedList<>();
        }
        size = 0;
    }

    protected int hash(K key) {
        int code = key.hashCode();
        return code;
    }

    protected void resize() {
        int oldCapacity = table.length;
        int newCapacity = 0;
        for (int i = 0; i < PRIMES.length; i++) {
            if (PRIMES[i] > oldCapacity * 2) {
                newCapacity = PRIMES[i];
                break;
            }
        }
        KVLinkedList<K, V>[] newTable = new KVLinkedList[newCapacity];
        for (int i = 0; i < newTable.length; i++) {
            newTable[i] = new KVLinkedList<>();
        }
        for (KVLinkedList<K, V> list : table) {
            Node<K, V> ptr = list.head;
            while (ptr != null) {
                K key = ptr.getKey();
                V value = ptr.getValue();
                int hash_code = hash(key);
                int location = hash_code % newTable.length;
                newTable[location].add(key, value);
                ptr = ptr.getNext();
            }
        }
        table = newTable;
        threshold = (int) (table.length * 0.75);
    }

    public void add(K key, V value) {
        int hash_code = hash(key);
        int location = hash_code % table.length;

        System.out.println("Adding " + value + " under key " + key + " at location " + location);

        table[location].add(key, value);
        size++;
        if (size >= threshold) {
            resize();
        }
    }

    public V get(K key) {
        int hash_code = hash(key);
        int location = hash_code % table.length;

        Node<K, V> node = table[location].get(key);
        return node != null ? node.getValue() : null;
    }

    // for iterator
    public Node<K, V> getNode(K key) {
        int hash_code = hash(key);
        int location = hash_code % table.length;

        Node<K, V> node = table[location].get(key);
        return node != null ? node : null;
    }

    public V remove(K key) {
        int hash_code = hash(key);
        int location = hash_code % table.length;

        Node<K, V> removed = table[location].remove(key);
        if (removed != null) {
            size--;
            return removed.getValue();
        }
        return null;
    }

    public boolean containsKey(K key) {
        int hash_code = hash(key);
        int location = hash_code % table.length;

        Node<K, V> node = table[location].get(key);
        return node != null;
    }

    public int size() {
        return this.size;
    }

    public KVHashMapIterator<K, V> iterator() {
        return new KVHashMapIterator<>(this);
    }

    public DynamicArray<K> getKeys() {
        DynamicArray<K> keys = new DynamicArray<>();
        for (KVLinkedList<K, V> list : table) {
            Node<K, V> ptr = list.head;
            while (ptr != null) {
                keys.add(ptr.getKey());
                ptr = ptr.getNext();
            }
        }
        return keys;
    }

}
