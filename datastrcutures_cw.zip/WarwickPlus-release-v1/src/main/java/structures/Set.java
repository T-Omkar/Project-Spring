package structures;

/**
 * A generic implementation of the IList iterface.
 */
public class Set<E extends Comparable<E>> {

    private DynamicArray<E> array = new DynamicArray<>();

    public boolean add(E element) {
        // Adds element to the list when it does not already exist.
        // Returns true on success and false otherwise.
        if (!(array.contains(element))) { // array does nor already contain the elemet,so add it
            array.add(element);
            return true;
        }
        return false;
    }

    public void clear() {
        array.clear();
    }

    public boolean contains(E element) {
        return array.contains(element);
    }

    public boolean isEmpty() {
        return array.isEmpty();
    }

    public boolean remove(E element) {
        return array.remove(element);
    }

    public int size() {
        return array.size();
    }

    // public E[] toArray() {
    // @SuppressWarnings("unchecked")
    // E[] result = (E[]) new Comparable[array.size()]; // create array of type E
    // for (int i = 0; i < array.size(); i++) {
    // result[i] = array.get(i); // cast each element to E and add it to the array
    // }
    // return result;
    // }

    public Object[] toArray() {
        Object[] result = new Object[array.size()];
        for (int i = 0; i < array.size(); i++) {
            result[i] = array.get(i);
        }
        return result;
    }

    public void addAll(Set<E> otherSet) {
        for (int i = 0; i < otherSet.size(); i++) {
            E element = otherSet.array.get(i);
            this.add(element);
        }
    }

    public DynamicArray<E> getArray() {
        return array;
    }

    public SetIterator<E> iterator() {
        return new SetIterator<>(this);
    }

    public void quickSort() {
        quickSort(0, array.size() - 1);
    }

    private void quickSort(int left, int right) {
        if (left < right) {
            int pivotIndex = partition(left, right);
            quickSort(left, pivotIndex - 1);
            quickSort(pivotIndex + 1, right);
        }
    }

    private int partition(int left, int right) {
        E pivot = array.get(right);
        int i = left - 1;
        for (int j = left; j < right; j++) {
            if (array.get(j).compareTo(pivot) < 0) {
                i++;
                E temp = array.get(i);
                array.set(i, array.get(j));
                array.set(j, temp);
            }
        }
        E temp = array.get(i + 1);
        array.set(i + 1, array.get(right));
        array.set(right, temp);
        return i + 1;
    }

    public Set<E> intersection(Set<E> other) {
        Set<E> intersection = new Set<>();

        this.quickSort();
        other.quickSort();

        int i = 0;
        int j = 0;

        while (i < this.size() && j < other.size()) {
            E a = this.array.get(i);
            E b = other.array.get(j);

            int cmp = a.compareTo(b);

            if (cmp < 0) {
                i++;
            } else if (cmp > 0) {
                j++;
            } else {
                intersection.add(a);
                i++;
                j++;
            }
        }

        return intersection;
    }

    // old set intersection- O(n^2) every time i think- must be slower but kept it
    // here in case i want to switch bc quick sort isnt great

/*     if set intersection operation is frequent
         its more efficient to store a sorted set and retain the order through the add
          and remove functions. If set intersection operation is rarer and sets
          are large, sorting the sets before taking their intersection will prob be more efficient.
*/
    // public Set<E> intersection(Set<E> otherSet) {
    // Set<E> result = new Set<E>();
    // for (int i = 0; i < array.size(); i++) {
    // E element = array.get(i);
    // if (otherSet.contains(element)) {
    // result.add(element);
    // }
    // }
    // return result;
    // }

}