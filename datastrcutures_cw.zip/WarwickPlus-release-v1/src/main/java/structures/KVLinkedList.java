package structures;

public class KVLinkedList<K extends Comparable<K>, V> {
    public Node<K, V> head;
    private int size;

    public KVLinkedList() {
        head = null;
        size = 0;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public void add(K key, V value) {
        Node<K, V> newNode = new Node<>(key, value);
        if (head == null) {
            head = newNode;
        } else {
            Node<K, V> current = head;
            while (current.getNext() != null) {
                current = current.getNext();
            }
            current.setNext(newNode);
        }
        size++;
    }

    public Node<K, V> get(K key) {
        Node<K, V> current = head;
        while (current != null) {
            if (current.getKey().compareTo(key) == 0) {
                return current;
            }
            current = current.getNext();
        }
        return null;
    }

    public Node<K, V> remove(K key) {
        if (head == null) {
            return null;
        }
        if (head.getKey().equals(key)) {
            Node<K, V> removed = head;
            head = head.getNext();
            size--;
            return removed;
        }
        Node<K, V> current = head;
        while (current.getNext() != null) {
            if (current.getNext().getKey().equals(key)) {
                Node<K, V> removed = current.getNext();
                current.setNext(current.getNext().getNext());
                size--;
                return removed;
            }
            current = current.getNext();
        }
        return null;
    }

    public Node<K, V> remove(K key, V value) {
        if (head == null) {
            return null;
        }
        if (head.getKey().equals(key) && head.getValue().equals(value)) {
            Node<K, V> removed = head;
            head = head.getNext();
            size--;
            return removed;
        }
        Node<K, V> current = head;
        while (current.getNext() != null) {
            if (current.getNext().getKey().equals(key) && current.getNext().getValue().equals(value)) {
                Node<K, V> removed = current.getNext();
                current.setNext(current.getNext().getNext());
                size--;
                return removed;
            }
            current = current.getNext();
        }
        return null;
    }

    public void addAll(KVLinkedList<K, V> other) {
        Node<K, V> current = other.head;
        while (current != null) {
            add(current.getKey(), current.getValue());
            current = current.getNext();
        }
    }

}
