package structures;

public class MaxHeap<E extends Comparable<E>> {

    private DynamicArray<HeapNode<E>> heapArray;
    private Integer size;

    public MaxHeap() {
        heapArray = new DynamicArray<>();
        size = 0;
    }

    public Integer size() {
        return this.size;
    }

    public void insert(E element, int priority) {
        HeapNode<E> node = new HeapNode<>(element, priority);
        heapArray.add(node);
        upHeap(this.size);
        this.size++;
    }

    public HeapNode<E> extractMax() {
        HeapNode<E> max = heapArray.get(0);
        heapArray.set(0, heapArray.get(this.size - 1));
        heapArray.remove(this.size - 1);
        this.size--;
        downHeap(0);

        // Print the heap
        System.out.println("Heap after extracting max:");
        for (int i = 0; i < heapArray.size(); i++) {
            System.out.print(heapArray.get(i).getData() + " ");
        }
        System.out.println();

        return max;
    }

    private void upHeap(int index) {
        if (index == 0) {
            return;
        }

        int parentIndex = (index - 1) / 2;
        if (heapArray.get(index).getPriority() > heapArray.get(parentIndex).getPriority()) {
            swap(index, parentIndex);
        }
        upHeap(parentIndex);
    }

    private void downHeap(int index) {
        if ((index * 2) + 1 > this.size - 1) {
            return;
        }

        int leftChildIndex = (2 * index) + 1;
        int rightChildIndex = (2 * index) + 2;

        if (rightChildIndex > this.size - 1) {
            if (heapArray.get(index).getPriority() < heapArray.get(leftChildIndex).getPriority()) {
                swap(index, leftChildIndex);
                downHeap(leftChildIndex);
            }
        } else {
            if (heapArray.get(leftChildIndex).getPriority() > heapArray.get(rightChildIndex).getPriority()) {
                if (heapArray.get(index).getPriority() < heapArray.get(leftChildIndex).getPriority()) {
                    swap(index, leftChildIndex);
                    downHeap(leftChildIndex);
                }
            } else {
                swap(index, rightChildIndex);
                downHeap(rightChildIndex);
            }
        }
    }

    private void swap(int index1, int index2) {
        HeapNode<E> element1 = heapArray.get(index1);
        HeapNode<E> element2 = heapArray.get(index2);
        heapArray.set(index1, element2);
        heapArray.set(index2, element1);
    }
}
