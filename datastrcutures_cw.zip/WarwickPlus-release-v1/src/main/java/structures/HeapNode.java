
package structures;

public class HeapNode<T extends Comparable<T>> implements Comparable<HeapNode<T>> {
    private T data;
    private int priority;

    public HeapNode(T data, int priority) {
        this.data = data;
        this.priority = priority;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    @Override
    public int compareTo(HeapNode<T> o) {
        return Integer.compare(priority, o.getPriority());
    }
}