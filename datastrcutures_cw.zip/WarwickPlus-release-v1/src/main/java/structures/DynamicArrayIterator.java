package structures;

import java.util.NoSuchElementException;

public class DynamicArrayIterator<E> {

    private DynamicArray<E> array;
    private int currentIndex;

    public DynamicArrayIterator(DynamicArray<E> array) {
        this.array = array;
        this.currentIndex = 0;
    }

    public boolean hasNext() {
        return currentIndex < array.size();
    }

    public E next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        E element = array.get(currentIndex);
        currentIndex++;
        return element;
    }

    public void remove() {
        throw new UnsupportedOperationException();
    }
}
