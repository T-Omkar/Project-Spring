package structures;

    public class MyBinaryTree<K extends Comparable<K>, V extends Comparable<V>> {

        private BTNode<K, V> root;

        /**
         * Adds a new node with the given key-value pair to the binary tree
         *
         * @param key   the key to add
         * @param value the value to add
         */
        public void add(K key, V value) {
            root = addRecursive(root, key, value);
        }

        /**
         * Recursively adds a new node with the given key-value pair to the binary tree
         *
         * @param current the current node in the recursion
         * @param key     the key to add
         * @param value   the value to add
         * @return the new node that was added
         */
        private BTNode<K, V> addRecursive(BTNode<K, V> current, K key, V value) {
            if (current == null) {
                return new BTNode<>(key, value);
            }
            int compare = key.compareTo(current.getKey());
            if (compare < 0) {
                current.setLeft(addRecursive(current.getLeft(), key, value));
            } else if (compare > 0) {
                current.setRight(addRecursive(current.getRight(), key, value));
            } else {
                // Handle duplicate keys
                Set<V> values = current.getValues();
                if (values == null) {
                    values = new Set<V>();
                    current.addValue(value);
                }
                values.add(value);
            }
            return current;
        }

        public Set<V> get(K key) {
            BTNode<K, V> node = getRecursive(root, key);
            if (node == null) {
                return null;
            }
            return node.getValues();
        }

        /**
         * Recursively finds the node with the given key in the binary tree
         *
         * @param current the current node in the recursion
         * @param key     the key to find
         * @return the node with the given key, or null if it is not in the tree
         */
        private BTNode<K, V> getRecursive(BTNode<K, V> current, K key) {
            if (current == null) {
                return null;
            }
            int compare = key.compareTo(current.getKey());
            if (compare == 0) {
                return current;
            } else if (compare < 0) {
                return getRecursive(current.getLeft(), key);
            } else {
                return getRecursive(current.getRight(), key);
            }
        }

        public void remove(K key, V value) {
            root = removeRecursive(root, key, value);
        }

        private BTNode<K, V> removeRecursive(BTNode<K, V> current, K key, V value) {
            if (current == null) {
                return null;
            }
            int compare = key.compareTo(current.getKey());
            if (compare < 0) {
                current.setLeft(removeRecursive(current.getLeft(), key, value));
            } else if (compare > 0) {
                current.setRight(removeRecursive(current.getRight(), key, value));
            } else {
                Set<V> values = current.getValues();
                if (values != null) {
                    values.remove(value); // remove the value from the linked list
                    if (values.isEmpty()) {
                        // if the linked list is now empty, remove the node
                        if (current.getLeft() == null && current.getRight() == null) {
                            return null;
                        } else if (current.getLeft() == null) {
                            return current.getRight();
                        } else if (current.getRight() == null) {
                            return current.getLeft();
                        } else {
                            BTNode<K, V> smallestNode = findSmallestNode(current.getRight());
                            current.setKey(smallestNode.getKey());
                            current.setValues(smallestNode.getValues());
                            current.setRight(removeSmallestNode(current.getRight()));
                        }
                    }
                }
            }
            return current;
        }

        private BTNode<K, V> findSmallestNode(BTNode<K, V> current) {
            if (current.getLeft() == null) {
                return current;
            } else {
                return findSmallestNode(current.getLeft());
            }
        }

        private BTNode<K, V> removeSmallestNode(BTNode<K, V> current) {
            if (current.getLeft() == null) {
                return current.getRight();
            } else {
                current.setLeft(removeSmallestNode(current.getLeft()));
                return current;
            }
        }


        /**
         * Returns a linked list of all the values in the binary tree between the given start and end keys, exclusive.
         *
         * @param start the starting key of the range
         * @param end   the ending key of the range
         * @return a linked list of all the values in the range, or an empty linked list if no values are in the range
         */
        public Set<V> getValuesBetween(K start, K end) {
            Set<V> values = new Set<>();
            getValuesBetweenRecursive(root, start, end, values);
            return values;
        }

        /**
         * Recursively adds all the values in the binary tree between the given start and end keys to the given linked list.
         *
         * @param current the current node in the recursion
         * @param start   the starting key of the range
         * @param end     the ending key of the range
         * @param values  the linked list to add the values to
         */
        private void getValuesBetweenRecursive(BTNode<K, V> current, K start, K end, Set<V> values) {
            if (current == null) {
                return;
            }
            if (current.getKey().compareTo(start) > 0 && current.getKey().compareTo(end) < 0) {
                values.addAll(current.getValues());
            }
            if (current.getKey().compareTo(start) > 0) {
                getValuesBetweenRecursive(current.getLeft(), start, end, values);
            }
            if (current.getKey().compareTo(end) < 0) {
                getValuesBetweenRecursive(current.getRight(), start, end, values);
            }
        }
    }
